A website to help you find the most important things on the site: Discord – Slite And others and also create a special web page linked to the discord موقع الكتروني لمساعدتك على إيجاد الأمور الأهم على الموقع اهمها Discord – Slite وغيرها

وايضا انشاء صفحة الكترونية مميزة مربوطة بالديسكورد
# ITerms of Service
🖋️**General Rules****1.** No spamming or flooding the chat with messages. Do not type in all caps.**2.** No text walls or large paragraphs of text.**3.** No bashing or heated arguments with other server members.**4.** No explicit or controversial messages.**5.** No racist or degrading content.**6.** No excessive cursing.**7.** No offensive names.**8.** Do not perform or promote the intentional use of glitches, hacks, bugs, and other exploits that will cause an incident within the community.9. Do not cause a nuisance in the community, repeated complaints from several members will lead to administrative action.10. Do not argue with staff. Decisions are final.11. Dua Lipa🎙️ **Voice Rules****1.** No voice chat surfing or switching channels repeatedly.**2.** No annoying, loud or high pitch noises.**3.** Reduce the amount of background noise, if possible. Resort to push to talk in your settings to reduce the issue.🛠️ **Bot Rules****1.** Do not spam commands.**2.** Do not use the bot to play loud music.⚠️**Do not ask for likes on your profile or randomly post your profile in chat, without context.**Opening a ticket for anything other than explicit support for the site will result in a mute and blacklist from opening tickets.Do not ping moderators without reasonable cause.

https://repbio.wordpress.com/terms

https://repbio.wordpress.com/privacy

**Soon**✨
