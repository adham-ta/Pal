Thank you for giving us your feedback! We listed some guidelines to help you:

If possible, open separate issues for each bug report. Avoid grouping bugs that are unrelated.

### What is the current behavior?

If the current behavior is a bug, please provide the steps to reproduce. if possible, provide the GitBook version being used (`gitbook -V`) and the system infromations (OS and version).

### What is the expected behavior?

How do you think, or how would you like it should behave.

#### For legacy.gitbook.com

Provide, if possible, your username and the URL of the concerned book.

----

The GitBook Team
