Better identify your spaces and improve your dashboard readability

 Our mission at GitBook is to provide a user-friendly and collaborative product for everyone to use. For us, it is the best way to improve the team's creativity for them to write and share the best ideas  
