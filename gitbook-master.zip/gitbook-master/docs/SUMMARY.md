# Summary

### Getting Started

* [About this documentation](README.md)
* [Installation and Setup](setup.md)

### Your Content

* [Directory structure](structure.md)
* [Pages and Summary](pages.md)
* [Configuration](config.md)
* [Glossary](lexicon.md)
* [Multi-Lingual](languages.md)
* [Markdown](syntax/markdown.md)
    * [Headings](syntax/markdown.md#headings)
    * [Paragraphs](syntax/markdown.md#paragraphs)
    * [Lists](syntax/markdown.md#lists)
    * [Links](syntax/markdown.md#links)
    * [Images](syntax/markdown.md#images)
    * [Blockquotes](syntax/markdown.md#blockquotes)
    * [Tables](syntax/markdown.md#tables)
    * [Code](syntax/markdown.md#code)
    * [HTML](syntax/markdown.md#html)
    * [Footnotes](syntax/markdown.md#footnotes)
* [AsciiDoc](syntax/asciidoc.md)
* [eBook and PDF](ebook.md)

### Customization

* [Templating](templating/README.md)
    * [Content References](templating/conrefs.md)
    * [Variables](templating/variables.md)
    * [Builtin](templating/builtin.md)
* [Plugins](plugins/README.md)
    * [Create a plugin](plugins/create.md)
    * [Hooks](plugins/hooks.md)
    * [Blocks](plugins/blocks.md)
    * [Filters](plugins/filters.md)
    * [API & Context](plugins/api.md)
    * [Test your plugin](plugins/testing.md)
* [Theming](themes/README.md)

--

* [FAQ](faq.md)
* [Examples](examples.md)
* [Release notes](https://github.com/GitbookIO/gitbook/blob/master/CHANGES.md)


